﻿<?php
$login_allow = true;
require("system.php");
if(ACT == "logout"){
	unset($_SESSION["dl"]);
	header("location:admin.php");
}else{

?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>加盟商后台管理 - 登录</title>

<link rel="stylesheet" type="text/css" href="css/style.css">

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/vector.js"></script>

</head>
<body>
<?php
if(isset($_POST["user"]) && isset($_POST["pass"])){
	$u = $_POST["user"];
	$p = $_POST["pass"];
	if(trim($u) == "" || trim($p) == ""){
		echo "<script>alert(\"账户密码不能为空\");</script>";
	}else{
	$admin = db("app_daili")->where(array("name"=>$u,"pass"=>$p,"lock"=>1))->find();
		if($admin){
			if($admin["endtime"] > time()){
				$_SESSION["dl"]["username"] = $u;
				$_SESSION["dl"]["password"] = $p;
				header("location:admin.php");
			}else{
				echo "<script>alert(\"加盟商身份已经过期\");</script>";
			}
		}else{
			echo "<script>alert(\"密码错误或者尚未激活\");</script>";
		}
	}
}


?>
<div id="container">
	<div id="output">
		<div class="containerT">
			<h1>加盟商登录</h1>
			<form action="./login.php" method="POST" class="panel-body wrapper-lg" role="form">
				<input type="text" placeholder="请输入账户" name="user">
				<input type="password" id="inputPassword" placeholder="请输入密码" name="pass">
				<button type="submit" class="btn btn-primary">立即登录</button></br></br>
				<a type="button" href="reg.php" class="btn btn-info">注册账户</a><br>
			</form>
		</div>
	</div>
</div>
<script type="text/javascript">
    $(function(){
        Victor("container", "output");   //登录背景函数
        $("#entry_name").focus();
        $(document).keydown(function(event){
            if(event.keyCode==13){
                $("#entry_btn").click();
            }
        });
    });
</script>
</body>
</html>
<?php 
}
include("footer.php");
 ?>