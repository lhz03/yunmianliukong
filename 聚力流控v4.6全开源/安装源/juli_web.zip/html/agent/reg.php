﻿<?php
$login_allow = true;
require("system.php");
if(ACT == "logout"){
	unset($_SESSION["dl"]);
	header("location:admin.php");
}else{

?>
<!DOCTYPE html>
<html lang="cn">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>加盟商后台管理 - 登录</title>

<link rel="stylesheet" type="text/css" href="css/style.css">

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/vector.js"></script>

</head>
<body>
<?php
if(isset($_POST["user"]) && isset($_POST["pass"])){
	$u = $_POST["user"];
	$p = $_POST["pass"];
	if(trim($u) == "" || trim($p) == ""){
		echo "<script>alert(\"账户密码不能为空！\");</script>";
	}else{

		$data["name"] = trim($u);
		$data["pass"] = trim($p);
		$data["endtime"] = time();
		$data["time"] = time();
		$data["balance"] = 0;
		$data["type"] = 0;
		$data["qq"] = $_POST["qq"];
		$data["lock"] = 0;
		$data["content"] = "";
		if(!db("app_daili")->where(["name"=>trim($u)])->find()){
			if(db("app_daili")->insert($data)){
					echo "<script>alert(\"注册成功 请联系超级管理员激活！\");</script>";
			}else{
					echo "<script>alert(\"注册失败！请联系超级管理员咨询！\");</script>";
			}
		}else{
			echo "<script>alert(\"注册失败！账户已存在！\");</script>";
		}
	}
}


?>
<div id="container">
	<div id="output">
		<div class="containerT">
			<h1>加盟商注册</h1>
			<form action="?" method="POST" class="panel-body wrapper-lg" role="form">
				<input type="text" placeholder="请输入账户" id="entry_name" name="user">
				<input type="password" placeholder="请输入密码" id="entry_password" name="pass">
				<input type="text" placeholder="联系QQ/微信" id="entry_name" name="qq">
				<button type="submit" class="btn btn-info">立即注册</button></br></br>
				<a type="button" href="login.php" class="btn btn-info">返回登录</a><br>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript">
    $(function(){
        Victor("container", "output");   //登录背景函数
        $("#entry_name").focus();
        $(document).keydown(function(event){
            if(event.keyCode==13){
                $("#entry_btn").click();
            }
        });
    });
</script>
</body>
</html>
<?php 
}
include("footer.php");
 ?>