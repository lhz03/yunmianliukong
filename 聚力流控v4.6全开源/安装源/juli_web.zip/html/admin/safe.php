<?php
	include('head.php');
	include('nav.php');
	$m = new Map();
 	if($_GET['act'] == 'del'){
		$port = file_get_contents("/root/res/portlist.conf");
		$p = '/port\s*([0-9]*)\s*tcp/';
		preg_match_all($p,$port,$m);
		echo '<span class="label label-default">代理端口</span>';
		foreach($m[1] as $vo){
			if($vo!=$_GET["port"]){
				$line[] = "port $vo tcp";
			}
		}
		$content = implode("\n",$line);
		file_put_contents("/root/res/portlist.conf",$content);
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
	}elseif($_GET['act'] == 'update'){
		
 		$limit = $_POST["limit"];
 		$content = "default {$limit}
		total 1000";
		$info = file_put_contents("/etc/openvpn/bwlimitplugin.cnf",$content);
 		
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
		
	}else{
		$action = "?act=update";
		
		$info = file_get_contents("/etc/openvpn/bwlimitplugin.cnf");
		$p = '/default\s([0-9]*)/';
		preg_match($p,$info,$m);
		
 ?>
<div class="main">
	<div class="box">
		<span class="label label-default">高级管理</span>
		<div style="clear:both;height:10px;"></div>
		<hr>
		<h3>TCP端口管理</h3>
		<?php
			$port = file_get_contents("/root/res/portlist.conf");
			$p = '/port\s*([0-9]*)\s*tcp/';
			preg_match_all($p,$port,$m);
			foreach($m[1] as $vo){
				echo $vo.'[<a href="?act=del&port='.$vo.'" onclick="if(confirm(\'删除后重启VPN生效\')){return true;}else{return false;}">删除</a>]&nbsp;';
			}
		?>
		<div style="clear:both;height:10px;"></div>
		<a class="btn btn-success" data-toggle="modal" data-target="#myModal" id="setting">添加TCP端口</a>
		<hr>
		<h3>WEB端口管理</h3>
		<div style="clear:both;height:10px;"></div>
		<a class="btn btn-info" data-toggle="modal" data-target="#myModal2" id="setting">修改WEB端口</a>
		
		<hr>
		<h3>系统操作</h3>
		<button type="submit" class="btn btn-hyx2" onclick="cmds('reboot')">重启服务器(reboot)</button>	
		<button type="submit" class="btn btn-danger" onclick="cmds('halt')">关闭服务器(halt)</button>
		</br></br>
		<button type="submit" class="btn btn-info" onclick="cmds('service sshd restart')">重启SSH服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('service sshd start')">启动SSH服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('service sshd stop')">停止SSH服务(慎重)</button>
		
		
		<hr>
		<h3>VPN操作</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('vpn restart')">重启VPN服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('vpn start')">启动VPN服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('vpn stop')">停止VPN服务(慎重)</button>
		
		
		<hr>
		<h3>用户状态扫描服务操作</h3>
		<button type="submit" class="btn btn-success" onclick="cmds('jk.sh')">启动用户状态扫描服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('killall -9 jk.sh')">停止用户状态扫描服务</button>
		
		<hr>
		<h3>用户流量监控服务操作</h3>
		<button type="submit" class="btn btn-success" onclick="cmds('FasAUTH.bin -c /etc/openvpn/auth_config.conf')">启动用户流量监控服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('killall -9 FasAUTH.bin')">停止用户流量监控服务</button>
		

		<hr>
		<h3>OpenVPN服务操作</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('systemctl restart openvpn@server1194')">重启TCP1服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('systemctl start openvpn@server1194')">启动TCP1服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('systemctl stop openvpn@server1194')">停止TCP1服务</button>
		</br></br>
		<button type="submit" class="btn btn-info" onclick="cmds('systemctl restart openvpn@server1195')">重启TCP2服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('systemctl start openvpn@server1195')">启动TCP2服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('systemctl stop openvpn@server1195')">停止TCP2服务</button>
		</br></br>
		<button type="submit" class="btn btn-info" onclick="cmds('systemctl restart openvpn@server1196')">重启TCP3服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('systemctl start openvpn@server1196')">启动TCP3服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('systemctl stop openvpn@server1196')">停止TCP3服务</button>
		</br></br>
		<button type="submit" class="btn btn-info" onclick="cmds('systemctl restart openvpn@server1197')">重启TCP4服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('systemctl start openvpn@server1197')">启动TCP4服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('systemctl stop openvpn@server1197')">停止TCP4服务</button>
		</br></br>
		<button type="submit" class="btn btn-info" onclick="cmds('systemctl restart openvpn@server-udp')">重启UDP服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('systemctl start openvpn@server-udp')">启动UDP服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('systemctl stop openvpn@server-udp')">停止UDP服务</button>
		
		<hr>
		<h3>MariaDB服务操作</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('service mariadb restart')">重启MariaDB服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('service mariadb start')">启动MariaDB服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('service mariadb stop')">停止MariaDB服务(慎重)</button>
		
		<hr>
		<h3>Apache服务操作</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('service httpd restart')">重启Apache服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('service httpd start')">启动Apache服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('service httpd stop')">停止Apache服务(慎重)</button>
		
		<hr>
		<h3>Dnsmasq服务操作</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('service dnsmasq restart')">重启Dnsmasq服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('service dnsmasq start')">启动Dnsmasq服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('service dnsmasq stop')">停止Dnsmasq服务</button>
		
		
		<hr>
		<h3>Iptables服务操作</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('service iptables restart')">重启Iptables服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('service iptables start')">启动Iptables服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('service iptables stop')">停止Iptables服务(慎重)</button>
		
		<hr>
		<h3>网卡操作(慎用)</h3>
		<button type="submit" class="btn btn-info" onclick="cmds('service network restart')">重启网卡服务</button>
		<button type="submit" class="btn btn-success" onclick="cmds('service network start')">启动网卡服务</button>
		<button type="submit" class="btn btn-danger" onclick="cmds('service network stop')">停止网卡服务(慎重)</button>
		
		
		
	</div>
</div>
	<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
				</button>
				<h4 class="modal-title" id="myModalLabel">
					添加TCP端口
				</h4>
			</div>
			<div class="modal-body">
				
				 <div class="form-group">
					<label for="name">请您注意</label>
					添加端口前 请在后台首页查看端口是否已经监听或者占用！本功能暂时只能添加TCP端口，如需添加UDP端口请登录服务器SSH输入port进行操作！</div>
				  <div class="form-group">
					<label for="name">请输入TCP端口</label>
				<input type="text" class="form-control" id="port" placeholder="请输入端口号...">
					
				  </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-warning" data-dismiss="modal">
					关闭窗口
				</button>
				<button type="button" class="btn btn-Violet1 save">
					提交数据
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->	

<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
				</button>
				<h4 class="modal-title" id="myModalLabel">
					修改WEB端口
					</h4>
			</div>
			<div class="modal-body">
				
				 <div class="form-group">
					<label for="name">请您注意</label>
					请保证端口没有被占用，否则，Apache可能无法启动（如果修改后无法打开，请联系何以潇处理！）</div>
				  <div class="form-group">
					<label for="name">请输入WEB端口</label>
						<input type="text" class="form-control" id="webport" placeholder="请输入端口号..." >
					
				  </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-warning" data-dismiss="modal">
					关闭窗口
				</button>
				<button type="button" class="btn btn-Violet1 save2" data-dismiss="modal">
					提交数据
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
$(function(){   
	   $(".save").click(function(){
		   var nums = $("#port").val();
		   if(nums == ""){
			   alert("请输入端口号");
		   } 
		   $.post('fas_service.php',{
			   "cmd":'/var/www/html/admin/lib/addport.sh tcp '+nums
			  
			},function(data){
				if(data.status == "success"){
					alert("执行完毕。请在后台首页查看是否已经添加成功");
					location.reload();
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
	   
	   $(".save2").click(function(){
		   var nums = $("#webport").val();
		   if(nums == ""){
			   alert("请输入端口号");
		   } 
		   $.post('fas_service.php',{
			   "cmd":'/var/www/html/admin/lib/modWebPort.sh '+nums
			  
			},function(data){
				if(data.status == "success"){
					alert("执行完毕。请尝试以新端口访问流控。");
					<?php
						$HOST = explode(":",$_SERVER["HTTP_HOST"]);
						$domain = $HOST[0];
						$port = $HOST[1];
					?>
					location.href="http://<?= $domain?>:"+nums+"/admin/";
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
	});
function cmds(line){
	if(confirm("确认执行此命令？部分命令执行后可能没有结果反馈")){
		$.post('fas_service.php',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("执行完毕");
				//location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
<?php
	}
	include('footer.php');
?>
