<?php


	//聚力网络科技 版权所有 
	//QQ: 1744744000
	
	
	
$file = "../../FAS.lock";

if(file_exists($file))
{
    require ("error.php");
	return;
}
else
{
    echo "";
}
?>
<?php


	//聚力网络科技 版权所有 
	//QQ: 1744744000
	
	
$display_login = true;
function getClientIP()  
{  
    global $ip;  
    if (getenv("HTTP_CLIENT_IP"))  
        $ip = getenv("HTTP_CLIENT_IP");  
    else if(getenv("HTTP_X_FORWARDED_FOR"))  
        $ip = getenv("HTTP_X_FORWARDED_FOR");  
    else if(getenv("REMOTE_ADDR"))  
        $ip = getenv("REMOTE_ADDR");  
    else $ip = "Unknow";  
    return $ip;  
}  
$cip = getClientIP();
if($_GET["act"] == "do_login"){
	require("system.php");
	$last_ip_file = R."/cache/last_ip.log";
	if(isset($_POST["user"]) && isset($_POST["pass"])){
	$u = $_POST["user"];
	$p = $_POST["pass"];
	if(trim($u) == "" || trim($p) == ""){
		die(json_encode(["status"=>"error","msg"=>"信息不完整"]));
	}else{
		$last_ip = file_get_contents($last_ip_file);
		if($cip != $last_ip){
			$auth_key = trim($_POST["auth_key"]);
			$local_key = file_get_contents("/var/www/auth_key.access");
			if($auth_key == "" || $auth_key != trim($local_key)){
				die(json_encode(["status"=>"error","msg"=>"口令错误"]));
			}
		}
		$admin = db("app_admin")->where(array("username"=>$u,"password"=>$p))->find();
		if($admin){
			$_SESSION["dd"]["username"] = $u;
			$_SESSION["dd"]["password"] = $p;
			file_put_contents($last_ip_file,$cip);
			die(json_encode(["status"=>"success","msg"=>""]));
		}else{
			die(json_encode(["status"=>"error","msg"=>"密码错误"]));
		}
	}
}
}elseif($_GET["act"] == "logout"){
	require("system.php");
	unset($_SESSION["dd"]);
	header("location:admin.php");
}else{
include("head1.php");
$last_ip_file = R."/cache/last_ip.log";
$last_ip = file_get_contents($last_ip_file);
?>
<!DOCTYPE html>
<html lang="zh" class="no-js">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<link rel="stylesheet" type="text/css" href="css/normalize.css" />
<link rel="stylesheet" type="text/css" href="css/demo.css" />
<link rel="stylesheet" type="text/css" href="css/component.css" />
</head>
<body>
		<div class="container demo-1">
			<div class="content">
				<div id="large-header" class="large-header">
					<canvas id="demo-canvas"></canvas>
					<div class="logo_box">
						<h3>后台管理 - 登录</h3>
						
						
						
						
							<div class="input_outer">
								<span class="u_user"></span>
								<input name="user" class="text" type="text" placeholder="请输入账户">
							</div>
							
							
							
							
							<div class="input_outer">
								<span class="us_uer"></span>
								<input name="pass" class="text" id="inputPassword" value="" type="password" placeholder="请输入密码">
							</div>
							
							
							
							<?php if($cip != $last_ip){ ?>
							<div class="input_outer">
								<span class="us_uer"></span>
								<input name="auth_key" class="text" id="inputPassword" value="" type="password" placeholder="请输入口令">
							</div>
							
							
							<?php } ?>
							
							<div class="mb2"><a class="act-but submit do_login" style="color: #FFFFFF">登录</a></div>
						
						
						
						
					</div>
				</div>
			</div>
		</div>
		<script src="js/TweenLite.min.js"></script>
		<script src="js/EasePack.min.js"></script>
		<script src="js/rAF.js"></script>
		<script src="js/demo-1.js"></script>
	</body>
</html>
<script>
	$(function(){
		$(".do_login").click(function(){
			var username = $("[name='user']").val();
			var password = $("[name='pass']").val();
			var auth_key = $("[name='auth_key']").val();
			if(username == "" || password == ""){
				alert("信息不完整");
			}else{
				$.post("?act=do_login",
				{
					"user":username,
					"pass":password,
					"auth_key":auth_key
				},function(data){
					if(data.status == "success"){
						window.location.href="admin.php";
					}else{
						alert(data.msg);
					}
				},"JSON");
			}
		});
	});
	</script>
<?php 
}
?>
<!-- 禁用鼠标右键 -->
<!-- 聚力网络科技 版权所有 -->
<!-- QQ: 1744744000 -->
<body leftmargin=0 topmargin=0 oncontextmenu='return false' ondragstart='return false' onselectstart ='return false' onselect='document.selection.empty()' oncopy='document.selection.empty()' onbeforecopy='return false' onmouseup='document.selection.empty()'>