﻿<?php



	//聚力网络科技 版权所有 
	//QQ: 1744744000
	
	
	
	
include('head.php');
include('nav.php');
?>
<script>
window.location.href='http://www.juliwangluo.cn/';
</script>
<?php include("footer.php");?>