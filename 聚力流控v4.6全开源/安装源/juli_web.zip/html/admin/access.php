<?php



	//聚力网络科技 版权所有 
	//QQ: 1744744000
	
	
 require("system.php");
   /* 获取远程服务器的公告 */

 $do = $_POST["do"];
 $cache=R."/cache/access.tmp";

 if($do == "getMsg" ){
	 if(is_file($cache) && time()-filemtime ($cache)<3*60){
		 $json = file_get_contents($cache);
	 }else{
		 $json = file_get_contents($cache);
	 }
	 if($json){
		 die($json);
	 }
	 die(json_encode(["status"=>"error"]));
 }else{
	 $json = file_get_contents($cache);
 }