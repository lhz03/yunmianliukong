<?php

	//上次短信发送时间
	$system_time = time();
	$last_time = $_SESSION["last_send"] == "" ? 0 : $_SESSION["last_send"];
	$al_time = $system_time - $last_time;
?>
<html lang="cn" class="bg-dark">
<head>
<title>新用户注册</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/ios_login_app.v2.css" type="text/css" />
<link rel="stylesheet" href="css/ios_login_bj.css" type="text/css" />
<link rel="shortcut icon" href="img/ios_icon.ico">
</head>
<style>
body,html{
    background: linear-gradient(#11C3F9, #72C472);
}
*{
	font-family:"微软雅黑"
}

.login-view{
	width:100%;
	height:100%;
	background-size: 100%;
	background-position:center;
}
.login-box{
	width:400px;
	margin-top:250px;
	background:#fff;
	float:right;
}
.login-title{
	padding:18px 15px;
	font-size:18px;
	color:#333;
	border-bottom:1px solid #efefef;
}

.login-bottom{
	padding:15px 15px;
	font-size:18px;
	color:#333;
	border-top:1px solid #efefef;
	background:#f8f8f8;
	text-align:right;
}
@media screen and (max-width:768px){
	.login-box{
		width:100%;
		margin-top:10px;
		background:#fff;
		float:none;
	}
}
</style>
<div class="login-view ">
<br><div class="container aside-xxl"> <a class="navbar-brand block view"><font color="#2F4F4F">新用户注册</font></a>
    <section class="panel panel-default bg-white m-t-lg panel-body wrapper-lg" method="POST" role="form">
        <div class="form-group">
        <label class="control-label">账号</label>
          <input style="right;height:45px;border-radius:5px;font-size:13px;" id="name" type="text" placeholder="请输入您要注册的账号" class="form-control input-lg">
        </div>
		
        <div class="form-group">
          <label class="control-label">密码</label>
          <input style="right;height:45px;border-radius:5px;font-size:13px;" id="pass" type="password" placeholder="请输入您要注册的密码" class="form-control input-lg">
        </div>
		
		<div class="form-group">
          <label class="control-label">确认密码</label>
          <input style="right;height:45px;border-radius:5px;font-size:13px;" id="pass2" type="password" placeholder="请再次输入您要注册的密码" class="form-control input-lg">
        </div>
		
		<div class="form-group">
		<div style="float:left;width:150px"><input type="text" class="form-control" id="code" placeholder="请输入验证码"></div>
		<div class=" col-sm-4;width:40%;" style="float:right"><img src="/app_api/mode/check_code.php?t=<?php echo time()?>" class="ccode" onclick='$(".ccode").attr({"src":"/app_api/mode/check_code.php?t="+Date.parse(new Date())});'> </div>
		 </div>
		</br></br></br>
		<button type="submit" class="btn btn-info btn-block"style="right;height:34px;border-radius:5px;font-size:13px;" onclick="reg()" >注册账号</button>

		<a type="button" class="btn btn-warning btn-block"style="right;height:34px;border-radius:5px;font-size:13px;" href="login.php" >返回登录</a><br>
			<div class="line line-dashed"></div>

<footer id="footer">
  <div class="text-center padder">

<footer id="footer">

<a type="button" >免流科技 - 版权所有</a> <br> <br>

    <p> <small>Version-19.02.27</small> </p>
    </section>
  </div>
  <script>
function reg(){
	if($("#code").val() == "" || $("#name").val() == "" || $("#pass").val() == "" || $("#pass2").val() == "" ){
		alert("任何一项均不能为空哦！");
	}else if($("#code").val() == ""){
		alert("验证码不得为空哦！");
		return;
	}else if($("#name").val() == ""){
		alert("账号不得为空哦！");
		return;
	}else if($("#pass").val() == ""){
		alert("密码不得为空哦！");
		return;
	}else if($("#pass").val() != $("#pass2").val()){
		alert("两次密码不一致哦！");
		return;
	}else{
		old_html = $(".cz").html();
		 $(".cz").html("注册中...");
		$.post(
			'reg.php?act=reg_in',{
				"username":$("#name").val(),
				"password":$("#pass").val(),
				"code":$("#code").val()
			},function(data){
				$(".cz").html(old_html);
				if(data.status == "success"){
					window.location.href="success.php";
				}else{
					$(".ccode").attr({"src":"/app_api/mode/check_code.php?t="+Date.parse(new Date())});
					alert(data.msg);
				}
			},"JSON"
		)
	}
}
function sysC(){
	window.myObj.colsePage();
}
$(function() { 
        $('#myModal').modal({ 
            keyboard: true 
        }) 
    }); 
</script>
<body leftmargin=0 topmargin=0 oncontextmenu='return false' ondragstart='return false' onselectstart ='return false' onselect='document.selection.empty()' oncopy='document.selection.empty()' onbeforecopy='return false' onmouseup='document.selection.empty()'>
<?php 
include("footer.php");
 ?>