<?php
$not_to_login = true;
require("system.php");
if(ACT == "logout"){
	unset($_SESSION["user"]);
	header("location:index.php");
}else{
include("api_head.php");
if(isset($_POST["username"]) && isset($_POST["password"]))
{
	$u = $_POST["username"];
	$p = $_POST["password"];
	if(trim($u) == "" || trim($p) == ""){
		echo "<script>alert(\"账户密码不能为空\");</script>";
	}else{
		$admin = db(_openvpn_)->where(array("iuser"=>$u,"pass"=>$p))->find();
		if($admin){
			$_SESSION["user"]["username"] = $u;
			$_SESSION["user"]["password"] = $p;
			header("location:index.php");
		}else{
			echo "<script>alert(\"密码错误请重新输入\");</script>";
		}
	}
}


?>
<html lang="cn" class="bg-dark">
<head>
<meta charset="utf-8" />
<title>个人中心登录系统</title>
<meta name="description" content="何以潇QQ：1744744000、个人中心登录系统">
<meta name="keywords" content="何以潇QQ：1744744000、个人中心登录系统">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/ios_login_app.v2.css" type="text/css" />
<link rel="stylesheet" href="css/ios_login_bj.css" type="text/css" />
<link rel="shortcut icon" href="img/ios_icon.ico">
</head>
<style>
body,html{
    background: linear-gradient(#11C3F9, #72C472);
}
*{
	font-family:"微软雅黑"
}

.login-view{
	width:100%;
	height:100%;
	background-size: 100%;
	background-position:center;
}
.login-box{
	width:400px;
	margin-top:250px;
	background:#fff;
	float:right;
}
.login-title{
	padding:18px 15px;
	font-size:18px;
	color:#333;
	border-bottom:1px solid #efefef;
}

.login-bottom{
	padding:15px 15px;
	font-size:18px;
	color:#333;
	border-top:1px solid #efefef;
	background:#f8f8f8;
	text-align:right;
}
@media screen and (max-width:768px){
	.login-box{
		width:100%;
		margin-top:10px;
		background:#fff;
		float:none;
	}
}
</style>
<div class="login-view ">
<br><div class="container aside-xxl"> <a class="navbar-brand block view"><font color="#2F4F4F">个人中心登录系统</font></a>
    <section class="panel panel-default bg-white m-t-lg">
	   <form action="./login.php" method="POST" class="panel-body wrapper-lg" role="form">
        <div class="form-group">
        <label class="control-label">账号</label>
          <input style="right;height:45px;border-radius:5px;font-size:13px;" type="text" placeholder="请输入您的账户" class="form-control input-lg" name="username" value="">
        </div>
        <div class="form-group">
          <label class="control-label">密码</label>
          <input style="right;height:45px;border-radius:5px;font-size:13px;" type="password" id="inputPassword" placeholder="请输入您的密码" class="form-control input-lg" name="password" value="">
        </div>
<button type="submit" class="btn btn-info btn-block"style="right;height:34px;border-radius:5px;font-size:13px;">登录</button>

<a type="button" href="reg.php" class="btn btn-warning btn-block"style="right;height:34px;border-radius:5px;font-size:13px;">注册</a><br>
        <div class="line line-dashed"></div>

<footer id="footer">
  <div class="text-center padder">

<footer id="footer">

<a type="button" >免流科技 - 版权所有</a> <br> <br>

    <p> <small>Version-19.02.27</small> </p>
      </form>
    </section>
  </div>
<body leftmargin=0 topmargin=0 oncontextmenu='return false' ondragstart='return false' onselectstart ='return false' onselect='document.selection.empty()' oncopy='document.selection.empty()' onbeforecopy='return false' onmouseup='document.selection.empty()'>
<?php 
}
include("footer.php");
 ?>