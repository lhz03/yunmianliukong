<?php

	//聚力网络科技 版权所有 
	//何以潇QQ：1744744000
	
	
	header("location:ios/");