<?php

	//聚力网络科技 版权所有 
	//何以潇QQ：1744744222
	
define("_host_","localhost");
define("_user_","root");
define("_pass_","newpass");
define("_port_","3306");
define("_ov_","vpndata");
define("_openvpn_","openvpn");
define("_iuser_","iuser");
define("_ipass_","pass");
define("_isent_","isent");
define("_irecv_","irecv");
define("_starttime_","starttime");
define("_endtime_","endtime");
define("_maxll_","maxll");
define("_other_","dlid,tian");
define("_i_","i");
